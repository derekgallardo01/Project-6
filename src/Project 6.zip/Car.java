
public class Car
{
	int license;
	int decal;
	
	Car (int _license, int _decal)
	{
		license = _license;
		decal = _decal;
	}
}
